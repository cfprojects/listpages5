<!--- listPages.cfm by Lars Gronholt AKA Aegis
www.eNTITy1.com

08/Aug/2008
version 1.03 --->
***Version 1.03
This is a minor update which addresses the problem experienced in the MS SQL Server version of this tag whereby users ordering resultset columns by low variance columns would recieve those results randomly ordered WITHIN the overall order chosen - eg: 300 results that have a column which contains a 'yes' or 'no', ordering by that column would result in pages of results ordered randomly within that overall order. Even clicking refresh would not show you the same results on any given page.

Also fixed an issue I discovered while setting up a test Railo server. The tag used a variable named cluster to define how many page hyperlinks you could see at once. This is an issue under Railo as Railo now uses a cluster scope for sharing information between clustered systems - information here:  http://www.railo.ch/blog/index.cfm/2008/7/6/Cluster-Scope .
Thanks to Gert Franz of Railo Technologies for the answer to the problem.

***Version 1.02
This is a security update. Several cfqueryparam tags were missing from the queries. These have been added back in. Checking was also added at line 120 (aprox.) to confirm that the url.orderby var is a value contained in the attributes.fieldnames var, if not, the url.orderby var is reset to the default value. This tag should now be safe from SQL injection attacks.


***Version 1.01

This tag has two variants currently: one for MySQL, and one for SQL Server (listPagesMYSQL.cfm and listPagesSQL.cfm respectively). Remove the MYSQL or SQL descriptor from the variant you wish to use and place it in the directory for the site you intend to use it with. it can then be called by pages from that site with <cf_listPages ... >. See below, or at the head of each file, for an example usage and a rundown of the attributes it includes.


<!--- EXAMPLE:
<cf_listPages
searchName="Search Users"
tableMainColour="##dbdbdb"
tableBorderColour="##003366"
tableHeadColour="##006699"
tableSecondaryColour="##c0c0c0"
datasource="#maindatasource#"
tableName="users"
primaryID="user_id"
fieldNames="u_first_name, u_last_name, u_account_status, u_access_level, u_last_login, u_logins"
displayFields="u_first_name, u_last_name, u_access_level, ucase(u_account_status), dtf|u_last_login, u_logins"
searchFields="u_first_name, u_last_name, u_access_level, u_account_status, u_last_login"
columnNames="First Name, Surname, Access Level, Active, Last Login, Logins"
searchFieldKind="v,v,i,v,d"
orderby="u_last_name,u_first_name"
pageLink="index.cfm?fuse=listUsers"
optLink1="index.cfm?fuse=editUser"
optLink1Name="Edit"
deleteLink="index.cfm?fuse=deleteUser"
addLink="index.cfm?fuse=addUser"
addLinkName="Add User"
records="20">
 

Call the page that loads this tag with a url variable of &reinit to prevent the tag from searching straight away--->
<!--- LATEST ADDITION
30/mar/2006
fixed join in query between usersupplied attributes.whereStatement and search refinement component
28/mar/05
recreated to no-longer use a session var to help with paging
01/jul/o5
added primaryName attribute so users can give their own values to the url value which carries IDs from this page to edit, delete etc pages.
22/jun/05
When you call the display fields you can (as per this example, now set dollar format, date format, time format, or datetime format - this example shows date time format) - basically, in the list of display fields, if you have a column such as mailout_send that you wish to be formatted differently, add the abreviation to the front of the column name with a pipe (|) to delimit it.

displayFields="mailout_title, dtf|mailout_send,mailout_status, name"

formats are:
datetimeformat = dtf
timeformat = tf
dateformat = df
dollarformat = $
--->
<!--- load attributes linked from <cf_listPages> --->
<!--- REQUIRED --->
<!--- records is the default for how many records to show per page --->
<cfparam name="attributes.records" default="20">
<!--- searchName is the name displayed on the page's search field --->
<cfparam name="attributes.searchName" default="Search">
<!--- primaryName is the name for the ID value added to urls linking away from individual records int he result list (eg: edit link) --->
<cfparam name="attributes.primaryName" default="pID">
<!--- REQUIRED - pagelink is used to set all pagenated links on the page to come back to the right spot --->
<cfparam name="attributes.pageLink" default="">
<!--- cluster sets maximum pages to display at once --->
<cfparam name="attributes.cluster" default="15">
<cfparam name="attributes.tableBorderColour" default="##003366">
<cfparam name="attributes.tableMainColour" default="##dbdbdb">
<cfparam name="attributes.tableHeadColour" default="##006699">
<cfparam name="attributes.tableSecondaryColour" default="##c0c0c0">
<!--- datasource - your datasource name in cfadministrator --->
<cfparam name="attributes.datasource" default="">
<!--- REQUIRED - tablename can be used to specify more than one table comma delimited --->
<cfparam name="attributes.tableName" default="">
<!--- REQUIRED - primaryID this field MUST be filled in and NOT be present in the fieldNames list as this attribute will automatically be included --->
<cfparam name="attributes.primaryID" default="">
<!--- REQUIRED - fieldNames is a comma delimited list of fields for the queries on the page --->
<cfparam name="attributes.fieldNames" default="">
<!--- REQUIRED - displayFields is a comma delimited list of fields that are used in attributes.fieldNames (doesnt have to be all of them ie ID), place them in the order they will display in output --->
<cfparam name="attributes.displayFields" default="">
<!--- REQUIRED - columnNames is a comma delimited list column titles for the output page, place them in the order they will display in output, must match up with displayFields --->
<cfparam name="attributes.columnNames" default="">
<!--- END REQUIRED --->
<!--- whereStatement to be used in queries on the page, can be blank, do not include "where", cannot include coldfusion code--->
<cfparam name="attributes.whereStatement" default="">
<!--- searchFields comma delimited list of fields used in search, combined with searchFieldKind, MUST match --->
<cfparam name="attributes.searchFields" default="">
<!--- searchFieldKind coma delimited list of fields types used in search, combined with searchFields, allows system to determine if field is date,varchar/char,int, MUST match- format eg: d,v,i, --->
<cfparam name="attributes.searchFieldKind" default="">
<!--- orderBy standard sql order by code without 'order by', can be blank --->
<cfparam name="attributes.orderBy" default="">
<!--- orderBy standard sql order by code without 'order by', can be blank --->
<cfparam name="attributes.orderDir" default="asc">
<!--- variable to set no results found message --->
<cfparam name="attributes.noResultsMsg" default="no records found">
<!--- optLink1 allows setting of a link to do something relating to that row, will automatically concat aatributes.primaryID to the end of the link in url var called pID - will show up with it's own column name options --->
<cfparam name="attributes.optLink1" default="">
<!--- optLink1Name allows setting of a link text for optLink1 --->
<cfparam name="attributes.optLink1Name" default="">
<!--- optLink2 allows setting of a link to do something relating to that row, will automatically concat aatributes.primaryID to the end of the link in url var called pID - will show up with it's own column name options --->
<cfparam name="attributes.optLink2" default="">
<!--- optLink2Name allows setting of a link text for optLink2 --->
<cfparam name="attributes.optLink2Name" default="">
<!--- variable to set number of columns - sets colspan for rows not associated with queries --->
<cfset viewColumns= listlen(attributes.columnNames)>
<!--- deletelink tells the system what to do when users click the delete button --->
<cfparam name="attributes.deleteLink" default="">
<!--- deleteMsg is the msg displayed when users click the delete button --->
<cfparam name="attributes.deleteMsg" default="Are you sure you want to delete this record?">
<!--- addLink provides a link to add a new record to whatever table --->
<cfparam name="attributes.addLink" default="">
<!--- addLinkName allows setting of a link text for addLink --->
<cfparam name="attributes.addLinkName" default="">
<!--- groupBy allows setting of group by properties for the 2 queries --->
<cfparam name="attributes.groupBy" default="">
<!--- variable tells system to add extra column for options --->